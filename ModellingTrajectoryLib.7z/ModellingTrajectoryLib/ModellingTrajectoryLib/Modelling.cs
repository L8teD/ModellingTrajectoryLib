﻿using ModellingTrajectoryLib.Helper;
using ModellingTrajectoryLib.Params;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModellingTrajectoryLib
{
    public class Modelling
    {
        ModellingFunctions func = new ModellingFunctions();
        public List<Point> points { get; private set; }
        public Modelling(double[] _latArray, double[] _lonArray, double[] _altArray)
        {
            Converter converter = new Converter();
            double[] latArray = converter.DegToRad(_latArray);
            double[] lonArray = converter.DegToRad(_lonArray);
            double[] altArray = _altArray;
            points = func.ModellingTrajectory(latArray, lonArray, altArray);
        }
    }
}
