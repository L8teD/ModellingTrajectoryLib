﻿using ModellingTrajectoryLib.Helper;
using ModellingTrajectoryLib.Params;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModellingTrajectoryLib
{
    class ModellingFunctions
    {
        double Rz = 6371000;
        double g = 9.81;
        double[] dLon;
        double[] ortDist;
        double[] ortDistAngle;
        double[] heading;
        double[] distance;
        double[] pitch;
        double[] dH;
        double rollDefault = -20;
        double roll;
        double UR;
        double radiusTurn;
        double timeTurn;
        double LUR_Distance;
        double PPM_Distance;
        Velocity[] velRoute;

        private Point[] startedPoints;

        bool turnHappened = false;


        private Converter converter = new Converter();
        private void InitStartedData(double[] latArray, double[] lonArray, double[] altArray)
        {
            InitStartedCoords(latArray, lonArray, altArray);
            InitStartedVelocitites(latArray.Length-1);
        }
        private void InitStartedCoords(double[] latArray, double[] lonArray, double[] altArray)
        {
            startedPoints = new Point[latArray.Length];
            for (int i = 0; i < latArray.Length; i++)
            {
                startedPoints[i] = new Point(latArray[i], lonArray[i], altArray[i]);
            }
        }
        private void InitStartedVelocitites(int length)
        {
            velRoute = new Velocity[length];
            for (int i = 0; i < length; i++)
            {
                velRoute[i] = new Velocity(900 / 3.6);
            }
        }
        private double[] MakeArray(int length)
        {
            return new double[length - 1];
        }
        private double ComputeOrtDistAngle(Point lastPoint, Point nextPoint)
        {
            return Math.Acos(Math.Sin(lastPoint.lat) * Math.Sin(lastPoint.lat) +
                Math.Cos(nextPoint.lat) * Math.Cos(nextPoint.lat) * Math.Cos(nextPoint.lon - lastPoint.lon));
        }
        private void InitParamsBetweenPPM()
        {
            dH = MakeArray(startedPoints.Length);
            for (int i = 0; i < dH.Length; i++)
            {
                dH[i] = 0;
            }
            dLon = MakeArray(startedPoints.Length);
            ortDist = MakeArray(startedPoints.Length);
            ortDistAngle = MakeArray(startedPoints.Length);
            heading = MakeArray(startedPoints.Length);
            distance = MakeArray(startedPoints.Length);
            pitch = MakeArray(startedPoints.Length);
            for (int k = 0; k < startedPoints.Length - 1; k++)
            {
                ComputeParamsBetweePPM(k);
            }
        }
        private void CheckParamsBetweenPPM(int k)
        {
            if (turnHappened)
            {
                ComputeParamsBetweePPM(k);
                turnHappened = false;

            }
        }
        private void ComputeParamsBetweePPM(int k)
        {
            dLon[k] = startedPoints[k + 1].lon - startedPoints[k].lon;
            ortDistAngle[k] = ComputeOrtDistAngle(startedPoints[k], startedPoints[k + 1]);
            ortDist[k] = Rz * ortDistAngle[k];
            distance[k] = Math.Sqrt(Math.Pow(ortDist[k], 2)) + dH[k];
            pitch[k] = Math.Atan2(dH[k], ortDist[k]);
            heading[k] = Math.Atan2(Math.Cos(startedPoints[k + 1].lat) * Math.Sin(dLon[k]),
                Math.Cos(startedPoints[k].lat) * Math.Sin(startedPoints[k + 1].lat) - Math.Sin(startedPoints[k + 1].lat) * Math.Cos(startedPoints[k + 1].lat) * Math.Cos(dLon[k]));
            heading[k] += heading[k] <= 0 ? 2 * Math.PI : 0;
            heading[k] -= heading[k] >= 360 ? 2 * Math.PI : 0;
        }

        private void ComputeLUR(int k)
        {
            UR = heading[k + 1] - heading[k];
            UR -= UR >= converter.DegToRad(180) ? converter.DegToRad(360) : 0;
            UR += UR <= converter.DegToRad(-180) ? converter.DegToRad(360) : 0;

            roll = UR >= 0 ? Math.Abs(rollDefault) : rollDefault;

            radiusTurn = Math.Pow(velRoute[k].value, 2) / (g * Math.Tanh(converter.DegToRad(roll)));
            timeTurn = radiusTurn * UR / velRoute[k].value;
            LUR_Distance = radiusTurn * Math.Tanh(0.5 * UR);
        }
        public List<Point> ModellingTrajectory(double[] latArray, double[] lonArray, double[] altArray)
        {
            List<Point> returnedPoints = new List<Point>()
            {
                new Point(latArray[0], lonArray[0], altArray[0])
            };

            List<Velocity> velocities = new List<Velocity>();
            List<AbsoluteOmega> absOmegaList = new List<AbsoluteOmega>();

            InitStartedData(latArray, lonArray, altArray);
            InitParamsBetweenPPM();

            int i = 0;
            double dt = 1;
            for (int k = 0; k < startedPoints.Length - 1; k++)
            {
                CheckParamsBetweenPPM(k);

                if (k != heading.Length - 1)
                    ComputeLUR(k);
                else
                    LUR_Distance = -1;

                PPM_Distance = Rz * ortDistAngle[k];
                double PPM_Disctance_prev = PPM_Distance + 1;
                while (LUR_Distance < PPM_Distance && PPM_Disctance_prev > PPM_Distance)
                {
                    velocities.Add(Velocity.GetProjectionsNZSK(velRoute[k].value, heading[k], pitch[k]));
                    absOmegaList.Add(AbsoluteOmega.GetProjectionsNZSK(velocities[i], Rz, returnedPoints[i]));
                    PPM_Disctance_prev = PPM_Distance;
                    returnedPoints.Add(Point.GetCoords(returnedPoints[i], absOmegaList[i], velocities[i], dt));
                    i++;
                    double ortDistAngleCurrent = ComputeOrtDistAngle(returnedPoints[i], startedPoints[k + 1]);
                    PPM_Distance = ortDistAngleCurrent * Rz;
                    
                }
                if ((k != heading.Length - 1) && (timeTurn >= 0.51))
                {
                    int timeTurnInt = (int) Math.Round(timeTurn);
                    int numberOfIterations = (int) (timeTurnInt / dt);
                    double dHeading = UR / numberOfIterations;
                    double headingTurn = heading[k];

                    turnHappened = true;

                    double dVelocityOnFullTurn = velRoute[k + 1].value - velRoute[k].value;
                    double dVelocityOnEveryIteration = dVelocityOnFullTurn != 0 ? dVelocityOnFullTurn / numberOfIterations : 0;

                    double j = 0;
                    while (j <= timeTurnInt)
                    {
                        double velocityValue = velocities[i-1].value + dVelocityOnEveryIteration;
                        double distTurn = velocityValue * dt;
                        double pitchTurn = Math.Atan2(0, distTurn);
                        headingTurn += dHeading;
                        velocities.Add(Velocity.GetProjectionsNZSK(velocityValue, headingTurn, pitchTurn));
                        absOmegaList.Add(AbsoluteOmega.GetProjectionsNZSK(velocities[i], Rz, returnedPoints[i]));

                        i++;
                        returnedPoints.Add(Point.GetCoords(returnedPoints[i - 1], absOmegaList[i - 1], velocities[i - 1], dt));
                        j += dt;
                    }
                }
            }
            return returnedPoints;
        }
    }
}
