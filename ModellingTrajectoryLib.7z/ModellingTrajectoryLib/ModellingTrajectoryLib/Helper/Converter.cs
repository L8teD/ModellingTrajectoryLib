﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModellingTrajectoryLib.Helper
{
    public class Converter
    {
        public double DegToRad(double valueDeg)
        {
            return valueDeg * Math.PI / 180;
        }
        public double[] DegToRad(double[] valuesDeg)
        {
            double[] valuesRad = new double[valuesDeg.Length];
            for (int i = 0; i < valuesDeg.Length; i++)
                valuesRad[i] = DegToRad(valuesDeg[i]);
            return valuesRad;
        }
        public double RadToDeg(double valueRad)
        {
            return valueRad * 180 / Math.PI;
        }
        public double[] RadtoDeg(double[] valuesRad)
        {
            double[] valuesDeg = new double[valuesRad.Length];
            for (int i = 0; i < valuesRad.Length; i++)
                valuesDeg[i] = RadToDeg(valuesRad[i]);
            return valuesDeg;
        }
    }
}
