﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModellingTrajectoryLib.Params
{
    class Acceleration
    {
        double X;
        double Y;
        double Z;
        public double E { get; private set; }
        public double N { get; private set; }
        public double H { get; private set; }
    }
}
