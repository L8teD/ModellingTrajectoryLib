﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModellingTrajectoryLib.Params
{
    public class AbsoluteOmega
    {
        double X;
        double Y;
        double Z;
        public double E { get; private set; }
        public double N { get; private set; }
        public double H { get; private set; }

        public static AbsoluteOmega GetProjectionsNZSK(Velocity velocity, double Rz, Point point)
        {
            AbsoluteOmega absOmega = new AbsoluteOmega();
            absOmega.E = velocity.N / (Rz + point.alt);
            absOmega.N = velocity.E / (Rz + point.alt);
            absOmega.H = velocity.E / Rz * Math.Tanh(point.lat);
            return absOmega;

        }
    }
}
