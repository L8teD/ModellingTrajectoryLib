﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModellingTrajectoryLib.Params
{
    public class Velocity
    {
        double X;
        double Y;
        double Z;

        public double E { get; private set; }
        public double N { get; private set; }
        public double H { get; private set; }

        public double value { get; private set; }
        public Velocity(double _value)
        {
            value = _value;
        }

        public static Velocity GetProjectionsNZSK(double value, double directAngle, double pitch)
        {
            Velocity velocity = new Velocity(value);
            velocity.H = velocity.value * Math.Sin(pitch);
            double horizontalVelocity = Math.Sqrt(Math.Pow(velocity.value, 2) - Math.Pow(velocity.H, 2));
            velocity.E = horizontalVelocity * Math.Sin(directAngle);
            velocity.N = horizontalVelocity * Math.Cos(directAngle);
            return velocity;
        }
    }
}
