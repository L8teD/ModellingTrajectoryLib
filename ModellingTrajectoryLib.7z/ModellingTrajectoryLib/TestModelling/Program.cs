﻿using System;
using System.Collections.Generic;
using System.Reflection;
using ModellingTrajectoryLib;
using ModellingTrajectoryLib.Helper;
using ModellingTrajectoryLib.Params;

namespace TestModelling
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] latArray = new double[] { 56, 57, 58, 59 };
            double[] lonArray = new double[] { 45, 46, 47, 48 };
            double[] altArray = new double[] { 0,0,0,0 };

            Modelling model = new Modelling(latArray, lonArray, altArray);
            double[] latInDeg = new double[model.points.Count];
            double[] lonInDeg = new double[model.points.Count];
            Converter converter = new Converter();
            for (int i= 0; i < model.points.Count; i++)
            {
                latInDeg[i] =  converter.RadToDeg(model.points[i].lat);
                lonInDeg[i] =  converter.RadToDeg(model.points[i].lon);
            }
            for (int i = 0; i < model.points.Count; i++)
                Console.WriteLine(latInDeg[i] + "   " + lonInDeg[i]);
            Console.ReadKey();



        }
    }
}
